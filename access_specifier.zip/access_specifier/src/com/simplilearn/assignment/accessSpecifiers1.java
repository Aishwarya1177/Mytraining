package com.simplilearn.assignment;

public class accessSpecifiers1 {

	public static void main(String[] args) {
		System.out.println("Dafault Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 
	}

}
