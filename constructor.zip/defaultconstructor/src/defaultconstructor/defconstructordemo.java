package defaultconstructor;

public class defconstructordemo {

	public static void main(String[] args) {
		empinfo emp1=new empinfo();
		empinfo emp2=new empinfo();

		emp1.display();
		emp2.display();
	}

}
