package defaultconstructor;

public class empinfo {
	 int id;
		String name;

	void display() {
		System.out.println(id+" "+name);
		}
	}

