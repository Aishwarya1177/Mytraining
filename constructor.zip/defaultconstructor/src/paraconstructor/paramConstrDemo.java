package paraconstructor;

public class paramConstrDemo {

	public static void main(String[] args) {
		std std1=new std(2,"Alex");
		std std2=new std(10,"Annie");
		std1.display();
		std2.display();
	}

}
